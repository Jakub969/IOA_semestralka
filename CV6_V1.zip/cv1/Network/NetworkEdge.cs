﻿using cv1.Interfaces;

namespace cv1.Network
{
    public class NetworkEdge : IDrawable2DObject
    {
        public void Draw(Graphics g)
        {
            throw new NotImplementedException();
        }

        public bool IsHitByMouse(Point mousePosition)
        {
            throw new NotImplementedException();
        }
    }
}
